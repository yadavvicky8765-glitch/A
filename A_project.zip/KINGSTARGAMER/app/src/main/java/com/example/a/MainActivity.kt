package com.example.a

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val pad = (20 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(pad, pad * 2, pad, pad)
        }

        root.addView(TextView(this).apply {
            text = "King Star Gamer 2.0 – फ्लोटिंग ऐप लॉन्चर"
            textSize = 22f
            gravity = Gravity.CENTER
        })
        root.addView(TextView(this).apply {
            text = "\nबबल चालू करो, फिर किसी भी गेम/ऐप के ऊपर उसे ड्रैग करके रखो। बबल पर टैप करने से सारे इंस्टॉल्ड ऐप्स की लिस्ट खुलेगी।\n"
            textSize = 15f
            gravity = Gravity.CENTER
        })

        fun addButton(label: String, onClick: () -> Unit) {
            root.addView(Button(this).apply {
                text = label
                setOnClickListener { onClick() }
            }, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ))
        }

        addButton("1. ओवरले परमिशन दो") {
            if (Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "परमिशन पहले से मिली हुई है ✔", Toast.LENGTH_SHORT).show()
            } else {
                startActivity(
                    Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")
                    )
                )
            }
        }

        addButton("2. बबल चालू करो") {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "पहले ओवरले परमिशन दो", Toast.LENGTH_LONG).show()
            } else {
                if (Build.VERSION.SDK_INT >= 33 &&
                    checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
                ) {
                    requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
                }
                val i = Intent(this, FloatingService::class.java)
                if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
                Toast.makeText(this, "बबल चालू हो गया", Toast.LENGTH_SHORT).show()
            }
        }

        addButton("3. बबल बंद करो") {
            stopService(Intent(this, FloatingService::class.java))
        }

        addButton("YouTube Channel") {
            startActivity(
                Intent(Intent.ACTION_VIEW, Uri.parse("https://youtube.com/@kingstargamer2.0"))
            )
        }

        setContentView(root)
    }
}
