package com.example.a

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable

class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val pad = (20 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(pad, pad * 2, pad, pad)
            setBackgroundColor(Color.parseColor("#121212"))
        }

        val channelUrl = "https://youtube.com/@kingstargamer2.0?si=VGuqaqwq16zUNS9q"

        root.addView(TextView(this).apply {
            text = "King Star Gamer 2.0"
            textSize = 26f
            setTextColor(Color.parseColor("#BB86FC"))
            typeface = Typeface.create("sans-serif-black", Typeface.NORMAL)
            gravity = Gravity.CENTER
        })
        root.addView(TextView(this).apply {
            text = channelUrl
            textSize = 13f
            setTextColor(Color.parseColor("#64B5F6"))
            paintFlags = paintFlags or android.graphics.Paint.UNDERLINE_TEXT_FLAG
            gravity = Gravity.CENTER
            setPadding(0, pad / 3, 0, pad / 2)
            setOnClickListener {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(channelUrl)))
            }
        })
        root.addView(TextView(this).apply {
            text = "B – फ्लोटिंग ऐप लॉन्चर"
            textSize = 18f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        })
        root.addView(TextView(this).apply {
            text = "\nबबल चालू करो, फिर किसी भी गेम/ऐप के ऊपर उसे ड्रैग करके रखो। बबल पर टैप करने से सारे इंस्टॉल्ड ऐप्स की लिस्ट खुलेगी।\n"
            textSize = 15f
            setTextColor(Color.parseColor("#CCCCCC"))
            gravity = Gravity.CENTER
        })

        fun addButton(label: String, onClick: () -> Unit) {
            root.addView(Button(this).apply {
                text = label
                setTextColor(Color.WHITE)
                isAllCaps = false
                background = GradientDrawable().apply {
                    setColor(Color.parseColor("#3700B3"))
                    cornerRadius = 40f
                }
                setOnClickListener { onClick() }
            }, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ))
        }

        addButton("1. ओवरले परमिशन दो") {
            if (Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "परमिशन पहले से मिली हुई है ✔", Toast.LENGTH_SHORT).show()
            } else {
                startActivity(
                    Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")
                    )
                )
            }
        }

        addButton("2. बबल चालू करो") {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "पहले ओवरले परमिशन दो", Toast.LENGTH_LONG).show()
            } else {
                if (Build.VERSION.SDK_INT >= 33 &&
                    checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
                ) {
                    requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
                }
                val i = Intent(this, FloatingService::class.java)
                if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
                Toast.makeText(this, "बबल चालू हो गया", Toast.LENGTH_SHORT).show()
            }
        }

        addButton("3. बबल बंद करो") {
            stopService(Intent(this, FloatingService::class.java))
        }

        setContentView(root)
    }
}
