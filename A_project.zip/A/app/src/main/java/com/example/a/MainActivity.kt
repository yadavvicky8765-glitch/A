package com.example.a

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.Html
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Locale

class MainActivity : Activity() {

    private val channelUrl = "https://youtube.com/@kingstargamer2.0?si=VGuqaqwq16zUNS9q"
    private val channelId = "UCtkWdnkAPa3ePQhMDxjaYSw"
    private val newVideoHours = 48L          // नया वीडियो इतने घंटे तक दिखेगा
    private val main = Handler(Looper.getMainLooper())

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(20), dp(40), dp(20), dp(20))
        }
        val scroll = ScrollView(this).apply {
            setBackgroundColor(Color.parseColor("#121212"))
            addView(root)
        }

        // ---- चैनल का नाम + लिंक ----
        root.addView(TextView(this).apply {
            text = "King Star Gamer 2.0"
            textSize = 26f
            setTextColor(Color.parseColor("#BB86FC"))
            typeface = Typeface.create("sans-serif-black", Typeface.NORMAL)
            gravity = Gravity.CENTER
        })
        root.addView(TextView(this).apply {
            text = channelUrl
            textSize = 13f
            setTextColor(Color.parseColor("#64B5F6"))
            paintFlags = paintFlags or Paint.UNDERLINE_TEXT_FLAG
            gravity = Gravity.CENTER
            setPadding(0, dp(6), 0, dp(10))
            setOnClickListener { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(channelUrl))) }
        })
        root.addView(TextView(this).apply {
            text = "👑 King Floater"
            textSize = 20f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        })

        // ---- नया वीडियो कार्ड (यहाँ अपने-आप जुड़ेगा) ----
        val videoSlot = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(videoSlot, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(14) })

        root.addView(TextView(this).apply {
            text = "\nबबल चालू करो, फिर किसी भी गेम/ऐप के ऊपर उसे ड्रैग करके रखो। बबल पर टैप करने से ऐप्स की लिस्ट खुलेगी, और ▶ YouTube / 📷 Instagram बटन से छोटी तैरती विंडो खुलेगी।\n"
            textSize = 15f
            setTextColor(Color.parseColor("#CCCCCC"))
            gravity = Gravity.CENTER
        })

        fun addButton(label: String, onClick: () -> Unit) {
            root.addView(Button(this).apply {
                text = label
                setTextColor(Color.WHITE)
                isAllCaps = false
                background = GradientDrawable().apply {
                    setColor(Color.parseColor("#3700B3"))
                    cornerRadius = 40f
                }
                setOnClickListener { onClick() }
            }, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
            ))
        }

        addButton("1. ओवरले परमिशन दो") {
            if (Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "परमिशन पहले से मिली हुई है ✔", Toast.LENGTH_SHORT).show()
            } else {
                startActivity(
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                )
            }
        }

        addButton("2. बबल चालू करो") {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "पहले ओवरले परमिशन दो", Toast.LENGTH_LONG).show()
            } else {
                if (Build.VERSION.SDK_INT >= 33 &&
                    checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
                ) {
                    requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
                }
                val i = Intent(this, FloatingService::class.java)
                if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
                Toast.makeText(this, "बबल चालू हो गया", Toast.LENGTH_SHORT).show()
            }
        }

        addButton("3. बबल बंद करो") {
            stopService(Intent(this, FloatingService::class.java))
        }

        setContentView(scroll)
        loadLatestVideo(videoSlot)
    }

    // ---------- चैनल का लेटेस्ट वीडियो (YouTube RSS से) ----------

    private fun loadLatestVideo(slot: LinearLayout) {
        Thread {
            try {
                val conn = URL("https://www.youtube.com/feeds/videos.xml?channel_id=$channelId")
                    .openConnection() as HttpURLConnection
                conn.connectTimeout = 8000
                conn.readTimeout = 8000
                val xml = conn.inputStream.bufferedReader().readText()

                val entry = Regex("<entry>(.*?)</entry>", RegexOption.DOT_MATCHES_ALL)
                    .find(xml)?.groupValues?.get(1) ?: return@Thread
                val id = Regex("<yt:videoId>(.*?)</yt:videoId>").find(entry)?.groupValues?.get(1) ?: return@Thread
                val title = Html.fromHtml(
                    Regex("<title>(.*?)</title>").find(entry)?.groupValues?.get(1) ?: "", Html.FROM_HTML_MODE_LEGACY
                ).toString()
                val published = Regex("<published>(.*?)</published>").find(entry)?.groupValues?.get(1) ?: return@Thread

                val time = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX", Locale.US).parse(published)?.time ?: return@Thread
                val ageHours = (System.currentTimeMillis() - time) / 3_600_000L
                if (ageHours > newVideoHours) return@Thread       // पुराना वीडियो, कुछ मत दिखाओ

                val bmp: Bitmap? = try {
                    BitmapFactory.decodeStream(URL("https://i.ytimg.com/vi/$id/hqdefault.jpg").openStream())
                } catch (e: Exception) { null }

                main.post { showVideoCard(slot, id, title, bmp) }
            } catch (e: Exception) {
                // इंटरनेट नहीं / कोई दिक्कत: चुपचाप कुछ नहीं दिखाएँगे
            }
        }.start()
    }

    private fun showVideoCard(slot: LinearLayout, id: String, title: String, bmp: Bitmap?) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(10), dp(10), dp(12))
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#1E1E2E"))
                setStroke(dp(2), Color.parseColor("#BB86FC"))
                cornerRadius = dp(14).toFloat()
            }
            setOnClickListener {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/watch?v=$id")))
            }
        }
        card.addView(TextView(this).apply {
            text = "🔥 नया वीडियो आ गया!"
            setTextColor(Color.parseColor("#FFD54F"))
            textSize = 15f
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 0, 0, dp(8))
        })
        if (bmp != null) {
            card.addView(ImageView(this).apply {
                setImageBitmap(bmp)
                adjustViewBounds = true
                scaleType = ImageView.ScaleType.FIT_CENTER
            }, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
            ))
        }
        card.addView(TextView(this).apply {
            text = title
            setTextColor(Color.WHITE)
            textSize = 14f
            setPadding(0, dp(8), 0, dp(4))
        })
        card.addView(TextView(this).apply {
            text = "▶ देखने के लिए टैप करो"
            setTextColor(Color.parseColor("#64B5F6"))
            textSize = 13f
        })
        slot.removeAllViews()
        slot.addView(card)
        slot.visibility = View.VISIBLE
    }
}
