package com.example.a

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.text.TextUtils
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.BaseAdapter
import android.widget.GridView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import kotlin.math.abs
import kotlin.math.max

class AppItem(val label: String, val pkg: String, val icon: Drawable)

class FloatingService : Service() {

    companion object {
        const val ACTION_STOP = "com.example.a.STOP"
        private const val CHANNEL_ID = "floating_bubble"
        private const val NOTIF_ID = 1
        private const val YOUTUBE_URL = "https://m.youtube.com"
        private const val INSTAGRAM_URL = "https://www.instagram.com"
    }

    private lateinit var wm: WindowManager
    private val main = Handler(Looper.getMainLooper())

    private var bubble: View? = null
    private var panel: View? = null
    private var mini: View? = null
    private var miniWeb: WebView? = null
    private var miniParams: WindowManager.LayoutParams? = null
    private var miniLevel = 1.0f
    private var miniFocusable = false
    private lateinit var bubbleParams: WindowManager.LayoutParams

    private val apps = mutableListOf<AppItem>()
    private var adapter: AppAdapter? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        createChannel()
        loadApps()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, notification)
        }
        if (bubble == null) showBubble()
        return START_STICKY
    }

    override fun onDestroy() {
        hidePanel()
        hideMini()
        bubble?.let { runCatching { wm.removeView(it) } }
        bubble = null
        super.onDestroy()
    }

    // फोन रोटेट होने पर सब कुछ नई स्क्रीन के हिसाब से सेट करो
    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        main.postDelayed({
            if (panel != null) {
                hidePanel()
                showPanel()
            }
            applyMiniSize()
            if (bubble != null) {
                bubbleParams.x = bubbleParams.x.coerceIn(0, max(0, screenW() - bubbleParams.width))
                bubbleParams.y = bubbleParams.y.coerceIn(0, max(0, screenH() - bubbleParams.height))
                runCatching { wm.updateViewLayout(bubble, bubbleParams) }
            }
        }, 300)
    }

    // ---------- Notification ----------

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel(CHANNEL_ID, "King Floater", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
    }

    private fun buildNotification(): Notification {
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), flags)
        val stop = PendingIntent.getService(
            this, 1, Intent(this, FloatingService::class.java).setAction(ACTION_STOP), flags
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_more)
            .setContentTitle("King Floater चालू है")
            .setContentText("बंद करने के लिए 'बंद करो' दबाओ")
            .setContentIntent(open)
            .addAction(0, "बंद करो", stop)
            .setOngoing(true)
            .build()
    }

    // ---------- Helpers ----------

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun screenW() = resources.displayMetrics.widthPixels
    private fun screenH() = resources.displayMetrics.heightPixels
    private fun isLandscape() = screenW() > screenH()

    private fun overlayType() =
        if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

    private fun makeDraggable(
        handle: View,
        getTarget: () -> View?,
        getParams: () -> WindowManager.LayoutParams?,
        onTap: (() -> Unit)?
    ) {
        val slop = ViewConfiguration.get(this).scaledTouchSlop
        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        var moved = false

        handle.setOnTouchListener { _, e ->
            val p = getParams()
            val t = getTarget()
            if (p == null || t == null) return@setOnTouchListener false
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = p.x; startY = p.y
                    touchX = e.rawX; touchY = e.rawY
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - touchX).toInt()
                    val dy = (e.rawY - touchY).toInt()
                    if (abs(dx) > slop || abs(dy) > slop) moved = true
                    if (moved) {
                        p.x = (startX + dx).coerceIn(0, max(0, screenW() - p.width))
                        p.y = (startY + dy).coerceIn(0, max(0, screenH() - p.height))
                        wm.updateViewLayout(t, p)
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) onTap?.invoke()
                    true
                }
                else -> false
            }
        }
    }

    // ---------- Bubble ----------

    private fun showBubble() {
        val size = dp(56)
        val view = TextView(this).apply {
            text = "B"
            setTextColor(Color.parseColor("#BB86FC"))
            textSize = 26f
            typeface = Typeface.create("sans-serif-black", Typeface.NORMAL)
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#F01E1E2E"))
                setStroke(dp(3), Color.parseColor("#BB86FC"))
            }
        }

        bubbleParams = WindowManager.LayoutParams(
            size, size, overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(8)
            y = dp(200)
        }

        makeDraggable(view, { bubble }, { bubbleParams }) { togglePanel() }
        wm.addView(view, bubbleParams)
        bubble = view
    }

    // ---------- Panel (ऐप्स की लिस्ट) ----------

    private fun togglePanel() {
        if (panel == null) showPanel() else hidePanel()
    }

    private fun showPanel() {
        val land = isLandscape()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(10), dp(12), dp(12))
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#F2212121"))
                cornerRadius = dp(20).toFloat()
            }
        }

        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        header.addView(TextView(this).apply {
            text = "King Floater"
            setTextColor(Color.parseColor("#BB86FC"))
            textSize = 16f
            typeface = Typeface.create("sans-serif-black", Typeface.NORMAL)
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        header.addView(TextView(this).apply {
            text = "✕"
            setTextColor(Color.WHITE)
            textSize = 20f
            setPadding(dp(12), 0, dp(4), 0)
            setOnClickListener { hidePanel() }
        })
        root.addView(header)

        // तैरती विंडो वाले बटन
        val chips = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun chip(label: String, onClick: () -> Unit) {
            chips.addView(TextView(this).apply {
                text = label
                setTextColor(Color.WHITE)
                textSize = 14f
                gravity = Gravity.CENTER
                setPadding(dp(14), dp(8), dp(14), dp(8))
                background = GradientDrawable().apply {
                    setColor(Color.parseColor("#3700B3"))
                    cornerRadius = dp(18).toFloat()
                }
                setOnClickListener { onClick() }
            }, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { rightMargin = dp(8) })
        }
        chip("▶ YouTube") { showMini(YOUTUBE_URL, "YouTube") }
        chip("📷 Instagram") { showMini(INSTAGRAM_URL, "Instagram") }
        root.addView(chips, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(8) })

        val a = AppAdapter()
        adapter = a
        val grid = GridView(this).apply {
            numColumns = if (land) 7 else 4
            adapter = a
            verticalSpacing = dp(8)
            selector = ColorDrawable(Color.TRANSPARENT)
            setOnItemClickListener { _, _, pos, _ -> launch(apps[pos]) }
        }
        root.addView(grid, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
        ).apply { topMargin = dp(8) })

        val params = WindowManager.LayoutParams(
            screenW() * 92 / 100,
            screenH() * (if (land) 80 else 65) / 100,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.CENTER }

        wm.addView(root, params)
        panel = root
        loadApps()
    }

    private fun hidePanel() {
        panel?.let { runCatching { wm.removeView(it) } }
        panel = null
        adapter = null
    }

    private fun launch(item: AppItem) {
        val i = packageManager.getLaunchIntentForPackage(item.pkg) ?: return
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(i)
        hidePanel()
    }

    // ---------- तैरती मिनी विंडो (YouTube / Instagram) ----------

    private fun showMini(url: String, title: String) {
        hidePanel()
        hideMini()

        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Color.parseColor("#1E1E2E"))
            setPadding(dp(10), 0, dp(4), 0)
        }
        val titleTv = TextView(this).apply {
            text = "☰ $title"
            setTextColor(Color.parseColor("#BB86FC"))
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
            maxLines = 1
            gravity = Gravity.CENTER_VERTICAL
        }
        bar.addView(titleTv, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
        fun addBtn(label: String, onClick: () -> Unit) {
            bar.addView(TextView(this).apply {
                text = label
                setTextColor(Color.WHITE)
                textSize = 16f
                gravity = Gravity.CENTER
                setPadding(dp(10), 0, dp(10), 0)
                setOnClickListener { onClick() }
            }, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT
            ))
        }
        addBtn("⌨") { toggleMiniFocus() }
        addBtn("➖") { resizeMini(-0.2f) }
        addBtn("➕") { resizeMini(0.2f) }
        addBtn("✕") { hideMini() }

        val web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false
            settings.useWideViewPort = true
            settings.loadWithOverviewMode = true
            webViewClient = WebViewClient()
            webChromeClient = WebChromeClient()
            setBackgroundColor(Color.BLACK)
        }
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true)
        web.loadUrl(url)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply {
                setColor(Color.BLACK)
                setStroke(dp(2), Color.parseColor("#BB86FC"))
            }
            setPadding(dp(2), dp(2), dp(2), dp(2))
        }
        root.addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(40)))
        root.addView(web, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        val p = WindowManager.LayoutParams(
            dp(300), dp(300), overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(10)
            y = dp(120)
        }

        mini = root
        miniWeb = web
        miniParams = p
        miniLevel = 1.0f
        miniFocusable = false
        applyMiniSize()
        makeDraggable(titleTv, { mini }, { miniParams }, null)
        wm.addView(root, p)
    }

    // स्क्रीन (सीधी/आड़ी) के हिसाब से विंडो का साइज़
    private fun applyMiniSize() {
        val p = miniParams ?: return
        val sw = screenW()
        val sh = screenH()
        val land = sw > sh
        val baseW = if (land) sw * 0.45f else sw * 0.80f
        val baseH = if (land) sh * 0.70f else sh * 0.36f
        p.width = (baseW * miniLevel).toInt().coerceIn(dp(180), (sw * 0.98f).toInt())
        p.height = (baseH * miniLevel).toInt().coerceIn(dp(160), (sh * 0.95f).toInt())
        p.x = p.x.coerceIn(0, max(0, sw - p.width))
        p.y = p.y.coerceIn(0, max(0, sh - p.height))
        mini?.let { if (it.isAttachedToWindow) runCatching { wm.updateViewLayout(it, p) } }
    }

    private fun resizeMini(delta: Float) {
        miniLevel = (miniLevel + delta).coerceIn(0.5f, 1.4f)
        applyMiniSize()
    }

    // कीबोर्ड मोड: टाइप करने के लिए विंडो को फोकस देना पड़ता है
    private fun toggleMiniFocus() {
        val p = miniParams ?: return
        val m = mini ?: return
        miniFocusable = !miniFocusable
        p.flags = if (miniFocusable) {
            p.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE.inv()
        } else {
            p.flags or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        }
        runCatching { wm.updateViewLayout(m, p) }
        if (miniFocusable) {
            miniWeb?.requestFocus()
            Toast.makeText(this, "कीबोर्ड मोड चालू (गेम रुक सकता है)। बंद करने के लिए ⌨ फिर दबाओ", Toast.LENGTH_LONG).show()
        }
    }

    private fun hideMini() {
        mini?.let { runCatching { wm.removeView(it) } }
        miniWeb?.let {
            it.stopLoading()
            it.destroy()
        }
        mini = null
        miniWeb = null
        miniParams = null
    }

    // ---------- Installed apps ----------

    private fun loadApps() {
        Thread {
            val pm = packageManager
            val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val list = pm.queryIntentActivities(intent, 0)
                .filter { it.activityInfo.packageName != packageName }
                .map { AppItem(it.loadLabel(pm).toString(), it.activityInfo.packageName, it.loadIcon(pm)) }
                .sortedBy { it.label.lowercase() }
            main.post {
                apps.clear()
                apps.addAll(list)
                adapter?.notifyDataSetChanged()
            }
        }.start()
    }

    private inner class AppAdapter : BaseAdapter() {
        override fun getCount() = apps.size
        override fun getItem(position: Int) = apps[position]
        override fun getItemId(position: Int) = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val item = apps[position]
            val cell = (convertView as? LinearLayout) ?: LinearLayout(this@FloatingService).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                setPadding(dp(2), dp(4), dp(2), dp(4))
                addView(ImageView(context).apply { id = 1 }, LinearLayout.LayoutParams(dp(48), dp(48)))
                addView(TextView(context).apply {
                    id = 2
                    setTextColor(Color.WHITE)
                    textSize = 11f
                    maxLines = 1
                    ellipsize = TextUtils.TruncateAt.END
                    gravity = Gravity.CENTER
                }, LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
                ))
            }
            cell.findViewById<ImageView>(1).setImageDrawable(item.icon)
            cell.findViewById<TextView>(2).text = item.label
            return cell
        }
    }
}
